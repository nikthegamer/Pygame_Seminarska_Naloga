import pygame
import random
from pygame import mixer

pygame.mixer.pre_init(44100, -16, 2, 512)
mixer.init()

SCREEN_WIDTH = 700
SCREEN_HEIGHT = 500



explosion_fx = pygame.mixer.Sound("Explosion.wav")
explosion_fx.set_volume(0.5)

Shot_fx = pygame.mixer.Sound("Shot.wav")
Shot_fx.set_volume(1.5)

Theme_fx = pygame.mixer.Sound("Theme.wav")
Theme_fx.set_volume(0.25)

rows = 5
cols = 5
last_enemy_shot = 1000
enemy_shot = pygame.time.get_ticks()
Lives = 3
Score = 0
HP_row = 3
HP_col = 3


Color_line = (34, 255, 0)
red = (255, 0, 0)
orange = (255, 128, 0)
yellow = (255, 255, 0)
green = (0, 255, 0)
black = (0, 0, 0)
white = (255, 255, 255)

pygame.display.set_caption('Space Invaderz (c)')
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))





from pygame.locals import (
    K_SPACE,
    K_LEFT,
    K_RIGHT,
    K_ESCAPE,
    KEYDOWN,
    QUIT,
)

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("Player.png")
        self.rect = self.image.get_rect()
        self.rect.center = [x,y]
        self.last_shot = pygame.time.get_ticks()

    def update(self, pressed_keys):
        speed = 5
        if pressed_keys[K_LEFT] and self.rect.left > 220:
            self.rect.x -= speed
        if pressed_keys[K_RIGHT] and self.rect.right < SCREEN_WIDTH-10:
            self.rect.x += speed

        time_after_shot = 500
        time_now = pygame.time.get_ticks()

        if pressed_keys[K_SPACE] and time_now - self.last_shot > time_after_shot:
            Shot_fx.play()
            bullet = Bullets(self.rect.centerx-1, self.rect.top)
            Bullet_group.add(bullet)
            self.last_shot = time_now

        global Lives
        global running
        global Score
        for Health in range(Lives):
            if pygame.sprite.spritecollide(self, Enemy_Bullet_Group, True):
                Lives -= 1
                Score -= 500
                explosion_fx.play()
                if pygame.sprite.spritecollide(self, Player_group, False):
                    self.image = pygame.image.load("Player_death.png")
                    explosion = Explosion(self.rect.centerx, self.rect.centery, 3)
                    Explosion_group.add(explosion)
                    pygame.time.delay(50)
                    self.rect.center = [(SCREEN_WIDTH - 240), SCREEN_HEIGHT - 50]
                    self.image = pygame.image.load("Player.png")
                    if len(Enemy_Bullet_Group) > 0:
                        for Enemy_Bullets in Enemy_Bullet_Group:
                            Enemy_Bullets.kill()
            if Lives == 0:
                running = False
                self.image = pygame.image.load("Player_death.png")

class Health1(pygame.sprite.Sprite):
    global Lives
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("Player.png")
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]
    def update(self):
        self.rect.x = 20
        self.rect.y = 20
        if Lives == 2:
            self.image = pygame.image.load("Player_death.png")

Health_group = pygame.sprite.Group()
def create_health_1():
    global Lives
    for hprow in range(HP_row):
        for item in range(HP_col):
            health1 = Health1(20 + item * 100, 20 * HP_row * 70)
            Health_group.add(health1)
    if Lives == 2:
        Health1.image = pygame.image.load("Player_death.png")
create_health_1()

class Health2(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("Player.png")
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]

    def update(self):
        self.rect.x = 80
        self.rect.y = 20
        if Lives == 1:
            self.image = pygame.image.load("Player_death.png")
def create_health_2():
    for hprow in range(HP_row):
        for item in range(HP_col):
            health2 = Health2(20 + item * 100, 20 * HP_row * 70)
            Health_group.add(health2)
create_health_2()

class Health3(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("Player.png")
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]

    def update(self):
        self.rect.x = 150
        self.rect.y = 20
        if Lives == 0:
            self.image = pygame.image.load("Player_death.png")

def create_health_3():
    for hprow in range(HP_row):
        for item in range(HP_col):
            health3 = Health3(20 + item * 100, 20 * HP_row * 70)
            Health_group.add(health3)
create_health_3()

class Health4(pygame.sprite.Sprite):
    global Lives
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("Controls.png")
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]
    def update(self):
        self.rect.x = 20
        self.rect.y = 150

def create_health_4():
    global Lives
    for hprow in range(HP_row):
        for item in range(HP_col):
            health4 = Health4(20 + item * 100, 20 * HP_row * 70)
            Health_group.add(health4)
    if Lives == 2:
        Health1.image = pygame.image.load("Player_death.png")
create_health_4()

Bullet_group = pygame.sprite.Group()
class Bullets(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("Bad_shot.png")
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]
    def update(self):
        global Score
        self.rect.y -= 5
        if self.rect.bottom < 0:
            self.kill()
        if pygame.sprite.spritecollide(self, Enemy_group, True):
            Score += 200
            self.kill()
            explosion_fx.play()
            explosion = Explosion(self.rect.centerx, self.rect.centery, 2)
            Explosion_group.add(explosion)


class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("invader_alien" + str(random.randint(1, 3)) + ".png")
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]
        self.move_counter = 0
        self.move = 1

    def update(self):
        self.rect.x += self.move
        self.move_counter += 1
        if abs(self.move_counter) > 15:
            self.move *= -1
            self.move_counter *= self.move

Enemy_group = pygame.sprite.Group()
def create_enemy():
    for row in range(rows):
        for item in range(cols):
            enemy = Enemy(255 + item * 100, 5 * row * 10 +30)
            Enemy_group.add(enemy)

Enemy_Bullet_Group = pygame.sprite.Group()
class Enemy_Bullets(pygame.sprite.Sprite):
    def __init__(self, x, y):

        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("Bad_shot.png")
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]
    def update(self):
        global Lives
        global running
        self.rect.y += 2
        if self.rect.top > SCREEN_HEIGHT:
            self.kill()



Explosion_group = pygame.sprite.Group()
class Explosion(pygame.sprite.Sprite):
    def __init__(self, x, y, size):
        pygame.sprite.Sprite.__init__(self)
        self.images = []
        for num in range(1, 6):
            img = pygame.image.load(f"exp{num}.png")
            if size == 1:
                img = pygame.transform.scale(img, (20, 20))
            if size == 2:
                img = pygame.transform.scale(img, (40, 40))
            if size == 3:
                img = pygame.transform.scale(img, (160, 160))
            self.images.append(img)
        self.index = 0
        self.image = self.images [self.index]
        self.rect = self.image.get_rect()
        self.rect.center = [x, y]
        self.counter = 0

    def update(self):
        Animation_speed = 3
        self.counter += 1
        if self.counter >= Animation_speed and self.index < len(self.images)-1:
            self.counter = 0
            self.index += 1
            self.image = self.images[self.index]
        if self.index >= len(self.images) - 1 and self.counter >= Animation_speed:
            self.kill()

create_enemy()

running = True
FPS = 60
clock = pygame.time.Clock()

Player_group = pygame.sprite.Group()
player = Player((SCREEN_WIDTH - 240), SCREEN_HEIGHT-50)
Player_group.add(player)


pygame.init()
while running:
    clock.tick(FPS)
    time_now = pygame.time.get_ticks()


    if time_now - enemy_shot > last_enemy_shot and len(Enemy_Bullet_Group) < 5 and len(Enemy_group) > 0:
        attacking_enemy = random.choice(Enemy_group.sprites())
        enemy_bullet = Enemy_Bullets(attacking_enemy.rect.centerx, attacking_enemy.rect.bottom)
        Enemy_Bullet_Group.add(enemy_bullet)
        last_enemy_shot = time_now


    pressed_keys = pygame.key.get_pressed()
    player.update(pressed_keys)
    Bullet_group.update()
    Enemy_group.update()
    Enemy_Bullet_Group.update()
    Health_group.update()


    Explosion_group.update()

    screen.fill((0, 0, 0))

    pygame.draw.line(screen, Color_line, (0, 0), (SCREEN_WIDTH, 0), 5)
    pygame.draw.line(screen, Color_line, (0, 0), (0, SCREEN_HEIGHT), 5)
    pygame.draw.line(screen, Color_line, (0, SCREEN_HEIGHT), (SCREEN_WIDTH, SCREEN_HEIGHT), 5)
    pygame.draw.line(screen, Color_line, (SCREEN_WIDTH, 0), (SCREEN_WIDTH, SCREEN_HEIGHT), 5)
    pygame.draw.line(screen, Color_line, (SCREEN_WIDTH - 490, 0), (SCREEN_WIDTH - 490, SCREEN_HEIGHT), 5)

    Player_group.draw(screen)
    Bullet_group.draw(screen)
    Enemy_group.draw(screen)
    Enemy_Bullet_Group.draw(screen)
    Explosion_group.draw(screen)
    Health_group.draw(screen)

    for event in pygame.event.get():
        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                running = False
        elif event.type == QUIT:
            running = False
        if len(Enemy_group) == 0:
            pygame.quit()

    font = pygame.font.Font('freesansbold.ttf', 32)
    score_text = font.render("Score: ", True, green, (0, 0, 0))
    score_text_rect = score_text.get_rect()
    score_text_rect.center = (70,450)

    screen.blit(score_text, score_text_rect)

    score = font.render(str(Score), True, green, (0, 0, 0))
    ScoreRect = score.get_rect()
    ScoreRect.center = (160, 452)

    screen.blit(score, ScoreRect)

    pygame.display.update()
    pygame.display.flip()
